﻿using Additionapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Additionapp.Businesslogic
{
    public static class Addargs
    {
        public static double Addition(this AddModel add, double Arg1, double Arg2)
        {
            try
            {
                double Result = Arg1 + Arg2;
                return Result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
