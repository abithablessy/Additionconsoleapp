
using Additionapp.Businesslogic;
using Additionapp.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Additionappunittest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Additiontest1()
        {
          AddModel am= new AddModel();
          var result=am.Addition(10, 15);
          var Expectedresult = 25;
          Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest2()
        {
            AddModel am = new AddModel();
            var result = am.Addition(-30, 15);
            var Expectedresult = -15;
            Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest3()
        {
            AddModel am = new AddModel();
            var result = am.Addition(-28, -10);
            var Expectedresult = -38;
            Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest4()
        {
            AddModel am = new AddModel();
            var result = am.Addition(108, -10);
            var Expectedresult = 98;
            Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest5()
        {
            AddModel am = new AddModel();
            var result = am.Addition(5.8999, 8.5677);
            var Expectedresult = 14.4676;
            Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest6()
        {
            AddModel am = new AddModel();
            var result = am.Addition(100.9999999999, 200.9999999999);
            var Expectedresult = 301.9999999998;
            Assert.AreEqual(Expectedresult, result);

        }
        [TestMethod]
        public void Additiontest7()
        {
            AddModel am = new AddModel();
            am.Addition(10000000000.9999999999, 2000000000000.9999999999);
            //var Expectedresult = 30000000002;
            //Assert.AreEqual(Expectedresult, result);

        }
    }
}