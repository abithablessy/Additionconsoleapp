﻿using Additionapp.Businesslogic;
using Additionapp.DAL;
using Additionapp.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Additionappunittest
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void Addsavetest1()
        {
          /*  AddDAL ad = new AddDAL(iconfig);

            var result = ad.Adddatacalc
            var Expectedresult = 25;
            Assert.AreEqual(Expectedresult, result);*/

        }
       
    }
}